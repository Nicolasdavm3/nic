﻿using System;
using System.Collections.Generic;

namespace MinhaAgenda
{
    // NOME COMPLETO: NICOLAS CONTENTE VALERIANO
    // TURMA: INF07
    // TURNO: MATUTINO

    class Contato
    {
        public string Nome { get; set; }
        public string Insta { get; set; }
        public string Bairro { get; set; }
        public string Cidade { get; set; }
        public int Idade { get; set; }
        public int MesAniversario { get; set; }
        public string Profissao { get; set; }

        public Contato(string nome, string insta, string bairro, string cidade, int idade, int mesAniversario, string profissao)
        {
            Nome = nome;
            Insta = insta;
            Bairro = bairro;
            Cidade = cidade;
            Idade = idade;
            MesAniversario = mesAniversario;
            Profissao = profissao;
        }
    }

    class Program
    {
 
        static int ExibirMenu()
        {
            int op = 0;
            Console.Clear();
            Console.WriteLine("Minha Agenda");
            Console.WriteLine("Exibir dados - 1");
            Console.WriteLine("Inserir contato - 2");
            Console.WriteLine("Alterar contato - 3");
            Console.WriteLine("Excluir contato - 4");
            Console.WriteLine("Localizar contato - 5");
            Console.WriteLine("Sair - 6");
            Console.Write("Opção: ");
            int.TryParse(Console.ReadLine(), out op);
            Console.Clear();
            return op;
        }

        static void ExibirContato(List<Contato> contatos)
        {
            Console.WriteLine("Exibir Contatos");
            foreach (var contato in contatos)
            {
                Console.WriteLine($"Nome: {contato.Nome} - Insta: {contato.Insta}");
                Console.WriteLine($"Bairro: {contato.Bairro}");
                Console.WriteLine($"Cidade: {contato.Cidade}");
                Console.WriteLine($"Idade: {contato.Idade}");
                Console.WriteLine($"Mês de Aniversário: {contato.MesAniversario}");
                Console.WriteLine($"Profissão: {contato.Profissao}");
                Console.WriteLine();
            }
            Console.ReadKey();
        }

        static void InserirContato(List<Contato> contatos)
        {
            try
            {
                Console.WriteLine("Inserir Contato");
                Console.Write("Nome: ");
                string nome = Console.ReadLine();
                Console.Write("Insta: ");
                string insta = Console.ReadLine();

                if (contatos.Exists(c => c.Insta == insta))
                {
                    Console.WriteLine("Contato já cadastrado");
                }
                else
                {
                    Console.Write("Bairro: ");
                    string bairro = Console.ReadLine();
                    Console.Write("Cidade: ");
                    string cidade = Console.ReadLine();
                    Console.Write("Idade: ");
                    int idade = int.Parse(Console.ReadLine());
                    Console.Write("Mês de Aniversário (1-12): ");
                    int mesAniversario = int.Parse(Console.ReadLine());
                    Console.Write("Profissão: ");
                    string profissao = Console.ReadLine();

                    contatos.Add(new Contato(nome, insta, bairro, cidade, idade, mesAniversario, profissao));
                }
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine("Erro: " + e.Message);
                Console.ReadKey();
            }
        }

        static void AlterarContato(List<Contato> contatos)
        {
            Console.WriteLine("Alterar Contato");
            Console.Write("Insta do contato a ser alterado: ");
            string instaAntigo = Console.ReadLine();

            var contato = contatos.Find(c => c.Insta == instaAntigo);
            if (contato != null)
            {
                Console.Write("Novo nome: ");
                contato.Nome = Console.ReadLine();
                Console.Write("Novo Insta: ");
                contato.Insta = Console.ReadLine();
                Console.Write("Novo Bairro: ");
                contato.Bairro = Console.ReadLine();
                Console.Write("Nova Cidade: ");
                contato.Cidade = Console.ReadLine();
                Console.Write("Nova Idade: ");
                contato.Idade = int.Parse(Console.ReadLine());
                Console.Write("Novo Mês de Aniversário (1-12): ");
                contato.MesAniversario = int.Parse(Console.ReadLine());
                Console.Write("Nova Profissão: ");
                contato.Profissao = Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Contato não encontrado");
            }
            Console.ReadKey();
        }

        static void ExcluirContato(List<Contato> contatos)
        {
            Console.WriteLine("Excluir Contato");
            Console.Write("Insta do contato a ser excluído: ");
            string insta = Console.ReadLine();

            var contato = contatos.Find(c => c.Insta == insta);
            if (contato != null)
            {
                contatos.Remove(contato);
                Console.WriteLine("Contato excluído com sucesso");
            }
            else
            {
                Console.WriteLine("Contato não encontrado");
            }
            Console.ReadKey();
        }

        static void LocalizarContato(List<Contato> contatos)
        {
            Console.WriteLine("Localizar Contato");
            Console.Write("Insta: ");
            string instaContato = Console.ReadLine();
            var contato = contatos.Find(c => c.Insta == instaContato);
            if (contato != null)
            {
                Console.WriteLine($"Nome: {contato.Nome} - Insta: {contato.Insta}");
                Console.WriteLine($"Bairro: {contato.Bairro}");
                Console.WriteLine($"Cidade: {contato.Cidade}");
                Console.WriteLine($"Idade: {contato.Idade}");
                Console.WriteLine($"Mês de Aniversário: {contato.MesAniversario}");
                Console.WriteLine($"Profissão: {contato.Profissao}");
            }
            else
            {
                Console.WriteLine("Contato não encontrado");
            }
            Console.ReadKey();
        }
        static void MostrarCabecalho()
        {
            Console.Clear();
            Console.WriteLine("NOME COMPLETO: NICOLAS CONTENTE VALERIANO");
            Console.WriteLine("TURMA: INF07");
            Console.WriteLine("TURNO: MATUTINO");
            Console.WriteLine();

            Console.WriteLine("Aperte Enter para continuar!");
            Console.ReadLine();
        }


        static void Main(string[] args)
        {
            MostrarCabecalho();

            List<Contato> contatos = new List<Contato>();

            // Dados temporários
            contatos.Add(new Contato("Fernandinho Beira Mar", "@beiramarvive33", "Zona Oeste", "RJ", 30, 5, "Comerciante"));
            contatos.Add(new Contato("Luciano Motta", "@amarelotdvida3357", "eng.velho federação", "Salvador", 25, 8, "Comerciante"));

            int op = 0;

            while (op != 6)
            {
                op = ExibirMenu();
                switch (op)
                {
                    case 1:
                        ExibirContato(contatos);
                        break;
                    case 2:
                        InserirContato(contatos);
                        break;
                    case 3:
                        AlterarContato(contatos);
                        break;
                    case 4:
                        ExcluirContato(contatos);
                        break;
                    case 5:
                        LocalizarContato(contatos);
                        break;
                }
            }
            // Salvar dados (não implementado)
        }
    }
}
